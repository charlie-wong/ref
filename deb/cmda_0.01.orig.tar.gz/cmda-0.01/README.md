# cmda
Linux command personal assistent
Display the command quik-use example colored

# install
make
make install

# uninstall
make uninstall
